#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

struct Link {
    double theta;
    double d;
    double a;
    double alpha;
};

class SerialLink {
public:
    SerialLink(vector<Link> links, string name) : links(links), name(name) {}

    void plot(vector<vector<double>> q) {
        // 实现机器人仿真运动的绘制
        // ...
    }

private:
    vector<Link> links;
    string name;
};

vector<double> pse(const vector<double>& As) {
    // 将角度转换为脉冲数
    vector<double> Pul;
    for (double a : As) {
        Pul.push_back(a * 6400 / 360);
    }
    return Pul;
}

vector<double> plspd(const vector<double>& vm) {
    // 计算脉冲速度
    vector<double> Pulspd;
    double a = 8400;
    for (double v : vm) {
        Pulspd.push_back(a / v);
    }
    return Pulspd;
}

pair<double, double> inverseSolutionOfKinematics(double x, double y, double L1, double L2) {
    // 逆解运动学，根据给定的坐标和连杆长度计算关节角度
    double c2 = (x * x + y * y - L1 * L1 - L2 * L2) / (2 * L1 * L2);
    double s2 = sqrt(1 - c2 * c2);
    double theta1 = atan2(y, x) - atan2(L2 * s2, L1 + L2 * c2);
    double theta2 = atan2(s2, c2);
    theta1 = theta1 / M_PI * 180;
    theta2 = theta2 / M_PI * 180;
    return make_pair(theta1, theta2);
}

void printVector(const vector<double>& vec) {
    // 打印向量的值
    for (double val : vec) {
        cout << val << " ";
    }
    cout << endl;
}

void calculateAndPrintResults(double L1, double L2, double v, double a, double T,
                              const pair<double, double>& p1, const pair<double, double>& p2) {
    int K1 = (p1.first < p2.first) ? 1 : -1;
    int K2 = (p1.second < p2.second) ? 1 : -1;

    double theta = abs(atan((p2.second - p1.second) / (p2.first - p1.first)));
    double l = sqrt(pow(p1.first - p2.first, 2) + pow(p1.second - p2.second, 2));

    double t_up = v / a;
    double t = (a * l - v * v) / (a * v);

    int index = 1;
    vector<double> x, y;

    // 计算加速段的轨迹点
    for (int i = 1; i <= round(t_up / T); i++) {
        double s = 0.5 * a * pow(i * T, 2);
        x.push_back(p1.first + K1 * s * cos(theta));
        y.push_back(p1.second + K2 * s * sin(theta));
        index++;
    }

    // 计算匀速段的轨迹点
    for (int i = 1; i <= round(t / T); i++) {
        double s = 0.5 * a * t_up * t_up + v * i * T;
        x.push_back(p1.first + K1 * s * cos(theta));
        y.push_back(p1.second + K2 * s * sin(theta));
        index++;
    }

    // 计算减速段的轨迹点
    for (int i = 1; i <= round(t_up / T); i++) {
        double s = 0.5 * a * t_up * t_up + v * t + v * i * T - 0.5 * a * pow(i * T, 2);
        x.push_back(p1.first + K1 * s * cos(theta));
        y.push_back(p1.second + K2 * s * sin(theta));
        index++;
    }

    vector<double> vx, vy, v_mix;
    for (int i = 1; i < index - 1; i++) {
        double vx_val = (x[i] - x[i - 1]) / T;
        double vy_val = (y[i] - y[i - 1]) / T;
        vx.push_back(vx_val);
        vy.push_back(vy_val);
        v_mix.push_back(sqrt(vx_val * vx_val + vy_val * vy_val));
    }

    vector<double> Theta1, Theta2;
    for (size_t i = 0; i < x.size(); i++) {
        pair<double, double> angles = inverseSolutionOfKinematics(x[i], y[i], L1, L2);
        Theta1.push_back(angles.first);
        Theta2.push_back(angles.second);
    }

    vector<double> Pulse1 = pse(Theta1);
    vector<double> Pulse2 = pse(Theta2);
    vector<double> PulseSpeed = plspd(v_mix);

    cout << "(Pulse1, Pulse2): ";
    for (size_t i = 0; i < Pulse1.size(); i++) {
        cout << "(" << Pulse1[i] << ", " << Pulse2[i] << ") ";
    }
    cout << endl;

    cout << "PulseSpeed: ";
    printVector(PulseSpeed);
}

int main() {
    double L1 = 120;
    double L2 = 70;
    double v = 2;       // 速度值，上位机用户输入，单位为mm/s
    double a = 1;       // 加速度值，上位机用户输入，单位为mm/(s^2)
    double T = 0.1;     // 插补周期，上位机用户输入，单位为s

    pair<double, double> p1 = make_pair(60, 60);      // 起点坐标，上位机用户输入
    pair<double, double> p2 = make_pair(150, 90);     // 终点坐标，上位机用户输入

    calculateAndPrintResults(L1, L2, v, a, T, p1, p2);

    return 0;
}
