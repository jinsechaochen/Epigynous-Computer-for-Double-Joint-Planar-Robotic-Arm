#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

// Function declarations
void pse(const vector<double>& As1, const vector<double>& As2, vector<pair<double, double>>& Pulses);
void plspd(const vector<double>& vm, vector<double>& Pulspd);
void Inverse_Solution_of_kinematics(double x, double y, double L1, double L2, double& theta1, double& theta2);
void interpolation(double L1, double L2, const double p0[], const double p1[], const double p2[], double T, double a, double v);

int main() {
    // Constants
    const double L1 = 120;
    const double L2 = 70;
    const double p0[] = { 90, 90 };           //圆心坐标，由上位机用户输入
    const double p1[] = { 90, 150 };          //起点坐标，由上位机用户输入
    const double p2[] = { 150, 90 };          //终点坐标，由上位机用户输入
    double T = 0.1;                                 //插补周期，单位为s
    double a = 2;                                   //加速度，由上位机用户输入，单位为mm/(s^2)
    double v = 1;                                   //速度，由上位机用户输入，单位为mm/s

    // Call the interpolation function
    interpolation(L1, L2, p0, p1, p2, T, a, v);

    return 0;
}

void pse(const vector<double>& As1, const vector<double>& As2, vector<pair<double, double>>& Pulses) {
    Pulses.reserve(As1.size());

    for (int i = 0; i < As1.size(); i++) {
        Pulses.push_back(make_pair(As1[i] * 6400 / 360, As2[i] * 6400 / 360));
    }
}

void plspd(const vector<double>& vm, vector<double>& Pulspd) {
    Pulspd.reserve(vm.size());

    double a = 8400;
    for (int i = 0; i < vm.size(); i++) {
        Pulspd.push_back(a / vm[i]);
    }
}

void Inverse_Solution_of_kinematics(double x, double y, double L1, double L2, double& theta1, double& theta2) {
    double c2 = (x * x + y * y - L1 * L1 - L2 * L2) / (2 * L1 * L2);
    double s2 = sqrt(1 - c2 * c2);
    theta1 = atan2(y, x) - atan2(L2 * s2, L1 + L2 * c2);
    theta2 = atan2(s2, c2);
    theta1 = theta1 / M_PI * 180;
    theta2 = theta2 / M_PI * 180;
}

void interpolation(double L1, double L2, const double p0[], const double p1[], const double p2[], double T, double a, double v) {
    // Variables
    double R = sqrt(pow(p2[1] - p0[1], 2) + pow(p2[0] - p0[0], 2));
    double theta2 = 180 / M_PI * atan2(p2[1] - p0[1], p2[0] - p0[0]);
    double theta1 = 180 / M_PI * atan2(p1[1] - p0[1], p1[0] - p0[0]);
    double alpha = theta2 - theta1;
    double s = abs(alpha * M_PI / 180 * R);
    double t_up = v / a;
    double t = (a * s - v * v) / (a * v);

    int index = 0;
    vector<double> x, y, v_mix, Theta1, Theta2;

    // Acceleration phase
    for (int i = 1; i <= round(t_up / T); i++) {
        double s = 0.5 * a * pow(i * T, 2);
        double d_angle = s / R;
        x.push_back(R * cos(theta1 + d_angle));
        y.push_back(R * sin(theta1 + d_angle));
        index++;
    }

    // Constant velocity phase
    for (int i = 1; i <= round(t / T); i++) {
        double s = 0.5 * a * pow(t_up, 2) + v * i * T;
        double d_angle = s / R;
        x.push_back(R * cos(theta1 + d_angle));
        y.push_back(R * sin(theta1 + d_angle));
        index++;
    }

    // Deceleration phase
    for (int i = 1; i <= round(t_up / T); i++) {
        double s = 0.5 * a * pow(t_up, 2) + v * t + v * i * T - 0.5 * a * pow(i * T, 2);
        double d_angle = s / R;
        x.push_back(R * cos(theta1 + d_angle));
        y.push_back(R * sin(theta1 + d_angle));
        index++;
    }

    // Adjusting the position
    for (int i = 0; i < index; i++) {
        x[i] += p0[0];
        y[i] += p0[1];
    }

    // Calculating velocities in rectangular coordinates
    for (int i = 1; i < index; i++) {
        double vx = (x[i] - x[i - 1]) / T;
        double vy = (y[i] - y[i - 1]) / T;
        v_mix.push_back(sqrt(pow(vx, 2) + pow(vy, 2)));
    }

    // D-H method for coordinate transformation
    vector<double> q;
    for (int i = 0; i < index; i++) {
        double theta1, theta2;
        Inverse_Solution_of_kinematics(x[i], y[i], L1, L2, theta1, theta2);
        Theta1.push_back(theta1);
        Theta2.push_back(theta2);
        q.push_back(theta1 * M_PI / 180);
        q.push_back(theta2 * M_PI / 180);
        q.push_back(0);
    }

    // Calculating Pulses
    vector<pair<double, double>> Pulses;
    pse(Theta1, Theta2, Pulses);

    // Calculating PulseSpeed
    vector<double> PulseSpeed;
    plspd(v_mix, PulseSpeed);

    // Printing the results
    cout << "Pulses: ";
    for (int i = 0; i < Pulses.size(); i++) {
        cout << "(" << Pulses[i].first << ", " << Pulses[i].second << ") ";
    }
    cout << endl;

    cout << "PulseSpeed: ";
    for (int i = 0; i < PulseSpeed.size(); i++) {
        cout << PulseSpeed[i] << " ";
    }
    cout << endl;
}
